# Jenkins CI scripts

Scripts invoked by Jenkins (our CI platform) to run gRPC test suites.
We run a comprehensive set of tests (unit, integration, interop,
performance, portability..) on each pull request and also periodically on
`master` and release branches.
